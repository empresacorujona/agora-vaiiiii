/* Interações globais leves do OwlConvenial. Sem bibliotecas externas. */
(() => {
    'use strict';

    const style = document.createElement('style');
    style.textContent = `
        .ui-reveal { opacity: 0; transform: translateY(12px); transition: opacity .45s ease, transform .45s ease; }
        .ui-reveal.is-visible { opacity: 1; transform: translateY(0); }
        .ui-loading { opacity: .75; cursor: wait; }
        @media (prefers-reduced-motion: reduce) {
            .ui-reveal, .ui-reveal.is-visible { opacity: 1; transform: none; transition: none; }
        }
    `;
    document.head.appendChild(style);

    // Entrada suave de elementos, sem bloquear a renderização da página.
    const animatedElements = document.querySelectorAll(
        '.card, .hospital-card, .consulta-card, .membro, .passo, section'
    );

    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries, currentObserver) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    currentObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12 });

        animatedElements.forEach(element => {
            element.classList.add('ui-reveal');
            observer.observe(element);
        });
    }

    // Evita envios repetidos e informa que o formulário está sendo processado.
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', () => {
            if (!form.reportValidity()) return;

            const button = form.querySelector('button[type="submit"], button:not([type])');
            if (!button || button.disabled) return;

            button.disabled = true;
            button.classList.add('ui-loading');
            button.setAttribute('aria-busy', 'true');
            button.dataset.originalText = button.textContent.trim();
            button.textContent = 'Enviando...';
        });
    });

    // Impede a seleção de datas anteriores ao dia atual.
    const dateInput = document.querySelector('input[type="date"]');
    if (dateInput) {
        const today = new Date();
        const localDate = [today.getFullYear(), String(today.getMonth() + 1).padStart(2, '0'), String(today.getDate()).padStart(2, '0')].join('-');
        dateInput.min = localDate;
    }
})();
